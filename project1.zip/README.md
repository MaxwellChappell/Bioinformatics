# Bioinformatics

project_1.py contains the run method and the actually method that translates the RNA to Amino acids.
          NOTE: still needs to deal with cases that don't contain the start sequence, and may modify
                 how we deal with cases without stop sequences later as well.

amino_acid_dictionary.py: Contains a function that creates a dictionary of RNA -> Amino Acid translations

hydrophobicity_scale.py: Contains a function that creates a dictionary of Amino Acids with their respective hydrophobicity

readfasta.py: Dr. Becks read FASTA code given to the Bio majors, reads FASTA from a file

writefasta.py: Code that writes FASTA fomated things to a txt
